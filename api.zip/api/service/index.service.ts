export class IndexService {
  static getMessage(): string {
    return 'Get in index.ts';
  }
}
